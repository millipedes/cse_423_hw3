# '\Uxxxxx'
# '\0'
# '\? \0 some other valid text'
