# Author: Matthew C. Lindeman
False None True and as assert break class continue def del elif else except
finally for from if import in is not lambda nonlocal not or global raise return
try while with yield pass ( ) [ ] : , ; + - * / | & = . % { } == != <= >= ~ ^ <<
>> ** += -= /= %= &= |= ^= <<= >>= **= // //= @ @= -> ... :=
