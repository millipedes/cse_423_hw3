# Author: Matthew C. Lindeman
def main():
	print()
		print
def f():
