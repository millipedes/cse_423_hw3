"hello world I forgot my quote
