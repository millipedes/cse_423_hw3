# Author: Matthew C. Lindeman
def main():
    i = -1_0
    for i < 10:
        i = i - 1
    print("see i =", i)
