# Author: Matthew C. Lindeman
def main():
    i = 10
    j = 10
    while i > 1:
        print('hello world')
        i = i - 1
    for j > 1:
        print("while")
        j = j - 1


def f():
    print('yay passed')



