# Author: Matthew C. Lindeman
def main():
    print('hello world')
    print("hello world")
