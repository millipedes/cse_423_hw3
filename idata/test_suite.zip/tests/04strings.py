# Author: Matthew C. Lindeman
"Hello World"
'Hello World'
'\nHello\tWorld\'\"\f\r\a'
"\nHello\tWorld\'\"\f\r\a"
